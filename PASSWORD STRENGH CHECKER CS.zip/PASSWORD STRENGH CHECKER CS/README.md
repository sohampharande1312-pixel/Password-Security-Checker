# CyberShield — Advanced Password Strength Analyzer

Welcome to CyberShield! This is a professional-grade, advanced password strength analyzer web application built with vanilla HTML/CSS/JavaScript.

## How to Run This Project

Because this project uses **modern ES Modules** (`import` and `export` in JavaScript), web browsers block the code from running directly off your hard drive (using the `file://` protocol) due to standard cross-origin security policies (CORS).

**You must run this project through a local web server.**

### Method 1: Using VS Code "Live Server" extension (Recommended)
If you are using Visual Studio Code:
1. Open VS Code and go to Extensions (`Ctrl+Shift+X`).
2. Search for **Live Server** (by Ritwick Dey) and install it.
3. Open `index.html` in VS Code.
4. Right-click anywhere in the code and select **Open with Live Server**.
5. Your browser will automatically open the project at `http://localhost:5500`.

### Method 2: Using Node.js (npx)
If you have Node.js installed on your computer:
1. Open a terminal in this project folder.
2. Run the following command:
   ```bash
   npx serve .
   ```
3. Open your browser and go to `http://localhost:3000`.

### Method 3: Using Python
If you have Python installed, you can use its built-in HTTP server:
1. Open a terminal in this project folder.
2. Run the following command:
   ```bash
   python -m http.server
   ```
3. Open your browser and go to `http://localhost:8000`.

## Features
* **Deep Password Analysis**: Shannon entropy calculation, character composition analysis, and unique character ratios.
* **Advanced Pattern Detection**: Identifies dictionary words, keyboard walks (e.g., "qwerty"), sequential letters/numbers, repeated characters, leetspeak, dates, and common affixes.
* **Data Breach Check**: Uses the Have I Been Pwned API to see if a password has been compromised. Uses the k-Anonymity model (sends only 5 characters of a SHA-1 hash) so **your password never leaves your browser**.
* **Crack Time Estimation**: Displays estimated times for how long it would take an attacker to crack the password under 5 different scenarios.
* **Secure Generator**: Includes a flexible random password and word-based passphrase generator using cryptographic randomness (`crypto.getRandomValues`).

---
*Built with security and privacy in mind.*
