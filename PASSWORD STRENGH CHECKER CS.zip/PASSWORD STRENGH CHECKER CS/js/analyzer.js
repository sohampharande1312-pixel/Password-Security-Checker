// ============================================================
// CyberShield — Core Password Analysis Engine
// Comprehensive password strength analysis with entropy
// calculation, character set analysis, and scoring
// ============================================================

import { detectPatterns } from './patterns.js';

/**
 * Analyze a password and return comprehensive analysis results
 * @param {string} password - The password to analyze
 * @returns {Object} Complete analysis result
 */
export function analyzePassword(password) {
  if (!password || password.length === 0) {
    return getEmptyResult();
  }

  const charsetAnalysis = analyzeCharset(password);
  const entropy = calculateEntropy(password, charsetAnalysis);
  const patterns = detectPatterns(password);
  const crackTimes = estimateCrackTimes(entropy, patterns);
  const score = calculateScore(password, entropy, patterns, charsetAnalysis);
  const level = getStrengthLevel(score);
  const suggestions = generateSuggestions(password, patterns, charsetAnalysis, score);

  return {
    password: maskPassword(password),
    length: password.length,
    entropy: Math.round(entropy * 100) / 100,
    charsetAnalysis,
    patterns,
    crackTimes,
    score: Math.round(score),
    level,
    suggestions
  };
}

/**
 * Calculate Shannon entropy of the password
 */
function calculateEntropy(password, charsetAnalysis) {
  if (password.length === 0) return 0;

  // Pool size based on character types used
  let poolSize = 0;
  if (charsetAnalysis.hasLowercase) poolSize += 26;
  if (charsetAnalysis.hasUppercase) poolSize += 26;
  if (charsetAnalysis.hasDigits) poolSize += 10;
  if (charsetAnalysis.hasSymbols) poolSize += 33;
  if (charsetAnalysis.hasUnicode) poolSize += 100; // Approximation for extended chars

  if (poolSize === 0) return 0;

  // Basic entropy: L * log2(N)
  let basicEntropy = password.length * Math.log2(poolSize);

  // Shannon entropy based on actual character frequency distribution
  const freq = {};
  for (const char of password) {
    freq[char] = (freq[char] || 0) + 1;
  }

  let shannonEntropy = 0;
  const len = password.length;
  for (const char in freq) {
    const p = freq[char] / len;
    shannonEntropy -= p * Math.log2(p);
  }
  shannonEntropy *= len;

  // Use the lower of the two as the effective entropy
  // This penalizes passwords with poor character distribution
  return Math.min(basicEntropy, basicEntropy * (shannonEntropy / basicEntropy + 0.5) / 1.5);
}

/**
 * Analyze the character composition of the password
 */
function analyzeCharset(password) {
  const analysis = {
    hasLowercase: false,
    hasUppercase: false,
    hasDigits: false,
    hasSymbols: false,
    hasUnicode: false,
    lowercaseCount: 0,
    uppercaseCount: 0,
    digitCount: 0,
    symbolCount: 0,
    unicodeCount: 0,
    uniqueChars: new Set(password).size,
    charsetSize: 0,
    typesUsed: 0
  };

  for (const char of password) {
    const code = char.charCodeAt(0);
    if (code >= 97 && code <= 122) { // a-z
      analysis.hasLowercase = true;
      analysis.lowercaseCount++;
    } else if (code >= 65 && code <= 90) { // A-Z
      analysis.hasUppercase = true;
      analysis.uppercaseCount++;
    } else if (code >= 48 && code <= 57) { // 0-9
      analysis.hasDigits = true;
      analysis.digitCount++;
    } else if (code >= 33 && code <= 126) { // printable symbols
      analysis.hasSymbols = true;
      analysis.symbolCount++;
    } else if (code > 126) { // unicode
      analysis.hasUnicode = true;
      analysis.unicodeCount++;
    }
  }

  // Calculate charset size
  if (analysis.hasLowercase) { analysis.charsetSize += 26; analysis.typesUsed++; }
  if (analysis.hasUppercase) { analysis.charsetSize += 26; analysis.typesUsed++; }
  if (analysis.hasDigits) { analysis.charsetSize += 10; analysis.typesUsed++; }
  if (analysis.hasSymbols) { analysis.charsetSize += 33; analysis.typesUsed++; }
  if (analysis.hasUnicode) { analysis.charsetSize += 100; analysis.typesUsed++; }

  return analysis;
}

/**
 * Estimate time to crack across different attack scenarios
 */
function estimateCrackTimes(entropy, patterns) {
  // Number of possible combinations
  const combinations = Math.pow(2, entropy);

  // Average guesses needed (50% of keyspace on average)
  const avgGuesses = combinations / 2;

  // Penalty factor from patterns (reduce effective combinations)
  let patternPenalty = 1;
  const criticalPatterns = patterns.filter(p => p.severity === 'critical');
  if (criticalPatterns.length > 0) {
    patternPenalty = 0.001; // Drastically reduce for critical patterns (common passwords)
  } else {
    const totalPenalty = patterns.reduce((sum, p) => sum + p.penalty, 0);
    patternPenalty = Math.max(0.01, 1 - Math.min(0.99, totalPenalty));
  }

  const effectiveGuesses = avgGuesses * patternPenalty;

  // Attack scenarios (guesses per second)
  const scenarios = {
    onlineThrottled: {
      name: 'Online Attack (Throttled)',
      description: 'Login forms with rate limiting (~100/sec)',
      speed: 100,
      icon: '🌐'
    },
    onlineUnthrottled: {
      name: 'Online Attack (Fast)',
      description: 'Unthrottled online service (~10K/sec)',
      speed: 10000,
      icon: '⚡'
    },
    offlineSlowHash: {
      name: 'Offline (bcrypt/scrypt)',
      description: 'Slow hashing algorithm (~10K/sec)',
      speed: 10000,
      icon: '🔒'
    },
    offlineFastHash: {
      name: 'Offline (MD5/SHA1)',
      description: 'Fast hash, single GPU (~10B/sec)',
      speed: 10000000000,
      icon: '💻'
    },
    massiveCluster: {
      name: 'GPU Cluster Attack',
      description: 'Nation-state level (~100T/sec)',
      speed: 100000000000000,
      icon: '🏢'
    }
  };

  const crackTimes = {};
  for (const [key, scenario] of Object.entries(scenarios)) {
    const seconds = effectiveGuesses / scenario.speed;
    crackTimes[key] = {
      ...scenario,
      seconds: seconds,
      display: formatTime(seconds)
    };
  }

  return crackTimes;
}

/**
 * Format seconds into human-readable time string
 */
function formatTime(seconds) {
  if (!isFinite(seconds) || seconds > 3.154e16) return '10M+ years';
  if (seconds < 0.001) return 'Instant';
  if (seconds < 1) return 'Less than a second';
  if (seconds < 60) return `${Math.round(seconds)} second${Math.round(seconds) !== 1 ? 's' : ''}`;

  const minutes = seconds / 60;
  if (minutes < 60) return `${Math.round(minutes)} minute${Math.round(minutes) !== 1 ? 's' : ''}`;

  const hours = minutes / 60;
  if (hours < 24) return `${Math.round(hours)} hour${Math.round(hours) !== 1 ? 's' : ''}`;

  const days = hours / 24;
  if (days < 30) return `${Math.round(days)} day${Math.round(days) !== 1 ? 's' : ''}`;

  const months = days / 30.44;
  if (months < 12) return `${Math.round(months)} month${Math.round(months) !== 1 ? 's' : ''}`;

  const years = days / 365.25;
  if (years < 100) return `${Math.round(years)} year${Math.round(years) !== 1 ? 's' : ''}`;
  if (years < 1000) return `${Math.round(years)} years`;
  if (years < 1000000) return `${Math.round(years / 1000)}K years`;
  if (years < 1000000000) return `${Math.round(years / 1000000)}M years`;
  return '1B+ years';
}

/**
 * Calculate overall score (0-100)
 */
function calculateScore(password, entropy, patterns, charsetAnalysis) {
  if (password.length === 0) return 0;

  let score = 0;

  // Length score (up to 30 points)
  score += Math.min(30, password.length * 2);

  // Entropy score (up to 35 points)
  score += Math.min(35, (entropy / 128) * 35);

  // Character diversity score (up to 20 points)
  score += charsetAnalysis.typesUsed * 5;

  // Unique character ratio (up to 15 points)
  const uniqueRatio = charsetAnalysis.uniqueChars / password.length;
  score += uniqueRatio * 15;

  // Pattern penalties
  for (const pattern of patterns) {
    switch (pattern.severity) {
      case 'critical':
        score *= (1 - pattern.penalty);
        break;
      case 'high':
        score -= pattern.penalty * 25;
        break;
      case 'medium':
        score -= pattern.penalty * 15;
        break;
      case 'low':
        score -= pattern.penalty * 8;
        break;
    }
  }

  // Minimum length penalties
  if (password.length < 8) score = Math.min(score, 25);
  if (password.length < 6) score = Math.min(score, 10);
  if (password.length < 4) score = Math.min(score, 5);

  return Math.max(0, Math.min(100, score));
}

/**
 * Determine strength level from score
 */
function getStrengthLevel(score) {
  if (score >= 90) return { label: 'Exceptional', color: '#00f5d4', class: 'exceptional', icon: '🛡️', index: 5 };
  if (score >= 75) return { label: 'Very Strong', color: '#00cc88', class: 'very-strong', icon: '💪', index: 4 };
  if (score >= 60) return { label: 'Strong', color: '#88cc00', class: 'strong', icon: '✅', index: 3 };
  if (score >= 40) return { label: 'Moderate', color: '#ffaa00', class: 'moderate', icon: '⚠️', index: 2 };
  if (score >= 20) return { label: 'Weak', color: '#ff6600', class: 'weak', icon: '❌', index: 1 };
  return { label: 'Very Weak', color: '#ff006e', class: 'very-weak', icon: '🚨', index: 0 };
}

/**
 * Generate actionable improvement suggestions
 */
function generateSuggestions(password, patterns, charsetAnalysis, score) {
  const suggestions = [];

  if (score >= 90) {
    suggestions.push({
      icon: '🏆',
      text: 'Excellent password! This password provides strong protection.',
      priority: 'success'
    });
    return suggestions;
  }

  // Length suggestions
  if (password.length < 12) {
    suggestions.push({
      icon: '📏',
      text: `Increase length to at least 16 characters. Your password is ${password.length} characters — length is the #1 factor for security.`,
      priority: 'high'
    });
  } else if (password.length < 16) {
    suggestions.push({
      icon: '📏',
      text: 'Consider extending to 16+ characters for sensitive accounts.',
      priority: 'medium'
    });
  }

  // Character diversity
  if (!charsetAnalysis.hasUppercase) {
    suggestions.push({ icon: '🔤', text: 'Add uppercase letters (A-Z) to expand the character pool.', priority: 'medium' });
  }
  if (!charsetAnalysis.hasLowercase) {
    suggestions.push({ icon: '🔡', text: 'Add lowercase letters (a-z) to expand the character pool.', priority: 'medium' });
  }
  if (!charsetAnalysis.hasDigits) {
    suggestions.push({ icon: '🔢', text: 'Add numbers (0-9) to increase complexity.', priority: 'medium' });
  }
  if (!charsetAnalysis.hasSymbols) {
    suggestions.push({ icon: '🔣', text: 'Add special symbols (!@#$%^&*) for maximum character pool.', priority: 'medium' });
  }

  // Pattern-based suggestions
  const patternTypes = new Set(patterns.map(p => p.type));

  if (patternTypes.has('dictionary')) {
    suggestions.push({
      icon: '📖',
      text: 'Avoid using common words or known passwords. Use a random passphrase instead.',
      priority: 'high'
    });
  }
  if (patternTypes.has('keyboard')) {
    suggestions.push({
      icon: '⌨️',
      text: 'Avoid keyboard walk patterns (qwerty, asdfgh). These are in every attacker\'s playbook.',
      priority: 'high'
    });
  }
  if (patternTypes.has('sequence')) {
    suggestions.push({
      icon: '🔢',
      text: 'Avoid sequential characters (abc, 123). Use random character placement.',
      priority: 'medium'
    });
  }
  if (patternTypes.has('repeat')) {
    suggestions.push({
      icon: '🔁',
      text: 'Avoid repeated characters or patterns. Each repeated character adds minimal security.',
      priority: 'medium'
    });
  }
  if (patternTypes.has('leet')) {
    suggestions.push({
      icon: '🎭',
      text: 'Leet speak (P@ssw0rd) doesn\'t fool modern cracking tools. Use truly random characters.',
      priority: 'high'
    });
  }
  if (patternTypes.has('date')) {
    suggestions.push({
      icon: '📅',
      text: 'Avoid dates — birthdays and anniversaries are among the first things attackers try.',
      priority: 'medium'
    });
  }

  // General tips
  if (score < 60) {
    suggestions.push({
      icon: '💡',
      text: 'Try a passphrase: combine 4-5 random, unrelated words (e.g., "Violet-Penguin-Rocket-37-Jazz")',
      priority: 'tip'
    });
  }

  suggestions.push({
    icon: '🔐',
    text: 'Use a password manager to generate and store unique passwords for every account.',
    priority: 'tip'
  });

  return suggestions;
}

/**
 * Return empty result for no input
 */
function getEmptyResult() {
  return {
    password: '',
    length: 0,
    entropy: 0,
    charsetAnalysis: {
      hasLowercase: false, hasUppercase: false, hasDigits: false,
      hasSymbols: false, hasUnicode: false,
      lowercaseCount: 0, uppercaseCount: 0, digitCount: 0,
      symbolCount: 0, unicodeCount: 0,
      uniqueChars: 0, charsetSize: 0, typesUsed: 0
    },
    patterns: [],
    crackTimes: {},
    score: 0,
    level: { label: 'Enter Password', color: '#555', class: 'none', icon: '🔒', index: -1 },
    suggestions: []
  };
}

/**
 * Mask password for display
 */
function maskPassword(password) {
  if (password.length <= 2) return '*'.repeat(password.length);
  return password[0] + '*'.repeat(password.length - 2) + password[password.length - 1];
}
