// ============================================================
// CyberShield — Top 1000 Most Common Passwords Dataset
// Source: Aggregated from public breach databases
// Used for dictionary matching in password analysis
// ============================================================

const COMMON_PASSWORDS = new Set([
  "123456","password","12345678","qwerty","123456789","12345","1234","111111",
  "1234567","dragon","123123","baseball","abc123","football","monkey","letmein",
  "shadow","master","666666","qwertyuiop","123321","mustang","1234567890","michael",
  "654321","superman","1qaz2wsx","7777777","121212","000000","qazwsx","123qwe",
  "killer","trustno1","jordan","jennifer","zxcvbnm","asdfgh","hunter","buster",
  "soccer","harley","batman","andrew","tigger","sunshine","iloveyou","2000",
  "charlie","robert","thomas","hockey","ranger","daniel","starwars","klaster",
  "112233","george","computer","michelle","jessica","pepper","1111","zxcvbn",
  "555555","11111111","131313","freedom","777777","pass","maggie","159753",
  "aaaaaa","ginger","princess","joshua","cheese","amanda","summer","love",
  "ashley","nicole","chelsea","biteme","matthew","access","yankees","987654321",
  "dallas","austin","thunder","taylor","matrix","mobilemail","william","corvette",
  "hello","martin","heather","secret","merlin","diamond","1234qwer","gfhjkm",
  "hammer","silver","222222","88888888","anthony","justin","test","bailey",
  "q1w2e3r4t5","patrick","internet","scooter","orange","11111","golfer",
  "cookie","richard","samantha","bigdog","guitar","jackson","whatever",
  "mickey","chicken","sparky","snoopy","maverick","phoenix","camaro","peanut",
  "morgan","welcome","falcon","cowboy","ferrari","samsung","andrea","smokey",
  "steelers","joseph","mercedes","dakota","arsenal","eagles","melissa","boomer",
  "booboo","spider","nascar","monster","tigers","yellow","xxxxxx","123123123",
  "gateway","marina","diablo","bulldog","qwer1234","compaq","purple","hardcore",
  "banana","junior","hannah","123654","porsche","lakers","iceman","money",
  "cowboys","987654","london","tennis","999999","ncc1701","coffee","scooby",
  "0000","miller","boston","q1w2e3r4","fuckoff","brandon","yamaha","chester",
  "mother","forever","johnny","edward","333333","oliver","redsox","player",
  "nikita","knight","fender","barney","midnight","please","brandy","chicago",
  "badboy","iwantu","slayer","rangers","charles","angel","flower","bigdaddy",
  "rabbit","wizard","bigdick","jasper","enter","rachel","chris","steven",
  "winner","adidas","victoria","natasha","1q2w3e4r","jasmine","winter","prince",
  "panties","marine","ghbdtn","fishing","cocacola","casper","oscar","tuber",
  "indian","yamato","skyline","roger","samsung1","brianna","austin1","breeze",
  "thunder1","cameron1","captain","passport","master1","diablo1","player1",
  "maverick1","justin1","ranger1","jordan1","michael1","batman1","dragon1",
  "hunter1","tigger1","sunshine1","sparky1","phoenix1","qwerty1","letmein1",
  "password1","password123","admin","administrator","root","toor","login",
  "guest","user","test123","pass123","admin123","root123","changeme",
  "welcome1","welcome123","monkey1","monkey123","master123","qwerty123",
  "abc1234","abcdef","abcd1234","1q2w3e","q1w2e3","1qaz2wsx3edc",
  "qweasdzxc","1234abcd","passwd","passw0rd","p@ssword","p@ssw0rd",
  "p@ss","trustme","letmein123","access14","starwars1","princess1",
  "dragon123","shadow1","shadow123","sunshine123","iloveyou1","iloveyou123",
  "football1","football123","baseball1","baseball123","soccer1","soccer123",
  "hockey1","hockey123","superman1","superman123","batman123","spider1",
  "spiderman","spiderman1","whatever1","whatever123","charlie1","charlie123",
  "donald","donald1","george1","thomas1","william1","robert1","michael123",
  "jennifer1","jessica1","amanda1","ashley1","nicole1","samantha1","michelle1",
  "taylor1","andrew1","matthew1","joshua1","daniel1","anthony1","joseph1",
  "david","david1","james","james1","john","john1","richard1","charles1",
  "christopher","christopher1","steven1","edward1","brian","brian1","kevin",
  "kevin1","mark","mark1","jason","jason1","timothy","timothy1","jeffrey",
  "jeffrey1","ryan","ryan1","jacob","jacob1","nicholas","nicholas1","eric",
  "eric1","stephen","stephen1","jonathan","jonathan1","larry","larry1",
  "scott","scott1","frank","frank1","benjamin","benjamin1","gregory",
  "gregory1","samuel","samuel1","patrick1","alexander","alexander1",
  "raymond","raymond1","jack","jack1","dennis","dennis1","jerry","jerry1",
  "tyler","tyler1","aaron","aaron1","henry","henry1","nathan","nathan1",
  "peter","peter1","walter","walter1","harold","harold1","douglas","douglas1",
  "password2","password12","pass1234","1password","mypassword","password!",
  "iloveu","lovely","rockyou","trustno","fuckyou","fuckyou1","asshole",
  "asshole1","bitch","bitch1","pussy","pussy1","dickhead","motherfucker",
  "sexy","sexy1","hottie","lovely1","cutie","beautiful","handsome",
  "sweetheart","sweetie","baby","baby1","angel1","honey","honey1","darling",
  "sunshine2","princess2","diamond1","crystal","crystal1","destiny","destiny1",
  "heaven","heaven1","faith","faith1","grace","grace1","hope","hope1",
  "apple","apple1","banana1","cherry","cherry1","peach","peach1","mango",
  "strawberry","blueberry","orange1","lemon","grape","coconut","watermelon",
  "pineapple","chocolate","chocolate1","vanilla","cookie1","brownie","candy",
  "candy1","sugar","sugar1","coffee1","caramel",
  "january","february","march","april","may","june","july","august",
  "september","october","november","december",
  "monday","tuesday","wednesday","thursday","friday","saturday","sunday",
  "spring","summer1","autumn","winter1","season",
  "red","blue","green","yellow1","purple1","black","white","silver1","golden",
  "newyork","london1","paris","tokyo","berlin","sydney","moscow","toronto",
  "losangeles","chicago1","houston","miami","boston1","seattle","denver",
  "portland","phoenix1","dallas1","atlanta","detroit","vegas","lasvegas",
  "america","canada","india","china","japan","russia","england","france",
  "germany","italy","spain","brazil","australia","mexico",
  "google","facebook","twitter","instagram","snapchat","tiktok","youtube",
  "amazon","netflix","spotify","microsoft","linkedin","reddit","pinterest",
  "samsung2","iphone","android","windows","linux","macos",
  "tesla","bmw","audi","honda","toyota","ford","chevy","dodge","jeep",
  "mercedes1","porsche1","ferrari1","lamborghini","mustang1","corvette1",
  "harley1","yamaha1","kawasaki","ducati","suzuki",
  "warriors","lakers1","celtics","bulls","rockets","spurs","heat","knicks",
  "yankees1","dodgers","redsox1","cubs","giants","packers","patriots",
  "cowboys1","eagles1","steelers1","broncos","seahawks","niners","chiefs",
  "ravens","raiders","bears","lions","dolphins","bengals","chargers",
  "arsenal1","chelsea1","liverpool","manchesterunited","manunited","barcelona",
  "realmadrid","juventus","bayern","psg",
  "gandalf","frodo","legolas","aragorn","sauron","ironman","hulk","thor",
  "captain","avengers","thanos","deadpool","wolverine","magneto","cyclops",
  "pikachu","pokemon","naruto","sasuke","goku","vegeta","luffy","zelda",
  "mario","luigi","peach2","bowser","kirby","link","samus","sonic",
  "minecraft","fortnite","roblox","valorant","overwatch","csgo","dota",
  "leagueoflegends","callofduty","halo","gta","skyrim","witcher","elden",
  "music","guitar1","piano","drums","violin","bass","trumpet","flute",
  "rock","metal","jazz","blues","hiphop","rap","country","classical",
  "eminem","drake","beyonce","taylor2","adele","rihanna","kanye","weeknd",
  "qwerty12","qwerty12345","asdfghjkl","zxcvbnm1","1q2w3e4r5t","qweasd",
  "1234567891","12345678910","asdfjkl","qwertyui","asdf1234","zxcv1234",
  "q1w2e3r4t5y6","1qazxsw2","zaq1xsw2","xsw2zaq1","2wsx3edc","3edc4rfv",
  "1234rewq","qwer4321","abcdefgh","abcdefg","abcde","abcdefghij",
  "0123456789","9876543210","0987654321","1357924680","2468013579",
  "aaaa","bbbb","cccc","dddd","eeee","ffff","gggg","hhhh","iiii","jjjj",
  "1111111","2222222","3333333","4444444","5555555","6666666","7777777",
  "8888888","9999999","0000000","11223344","99887766","aabbccdd",
  "trustno2","letmein2","welcome2","monkey2","dragon2","shadow2","master2",
  "qwerty2","password3","abc12345","123abc","321cba","test1234","testing",
  "testing1","testing123","testtest","pass1","pass12","pass1234","passcode",
  "mypass","mypass1","mypassword1","secret1","secret123","private","private1",
  "nothing","nothing1","none","null","empty","blank","default","default1",
  "temp","temp1","temp123","temporary","trial","demo","sample","example",
  "backup","backup1","recovery","recover","reset","reset1","update","update1",
  "qwerty!","password!1","letmein!","iloveyou!","welcome!","monkey!",
  "abc123!","football!","baseball!","shadow!","master!","dragon!",
  "starwars!","princess!","whatever!","charlie!","hello1","hello123",
  "goodbye","goodbye1","please1","thanks","thanks1","sorry","sorry1"
]);

// Common keyboard patterns for spatial pattern detection
const KEYBOARD_PATTERNS = {
  qwerty: [
    ['q','w','e','r','t','y','u','i','o','p'],
    ['a','s','d','f','g','h','j','k','l'],
    ['z','x','c','v','b','n','m']
  ],
  qwertyShifted: [
    ['Q','W','E','R','T','Y','U','I','O','P'],
    ['A','S','D','F','G','H','J','K','L'],
    ['Z','X','C','V','B','N','M']
  ],
  numpad: [
    ['7','8','9'],
    ['4','5','6'],
    ['1','2','3'],
    ['0']
  ]
};

// Build adjacency graph for keyboard pattern detection
function buildAdjacencyGraph(layout) {
  const graph = {};
  for (let row = 0; row < layout.length; row++) {
    for (let col = 0; col < layout[row].length; col++) {
      const char = layout[row][col];
      const neighbors = [];
      // Check all 8 directions
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = row + dr;
          const nc = col + dc;
          if (nr >= 0 && nr < layout.length && nc >= 0 && nc < layout[nr].length) {
            neighbors.push(layout[nr][nc]);
          }
        }
      }
      graph[char] = neighbors;
    }
  }
  return graph;
}

const QWERTY_GRAPH = buildAdjacencyGraph(KEYBOARD_PATTERNS.qwerty);
const QWERTY_GRAPH_UPPER = buildAdjacencyGraph(KEYBOARD_PATTERNS.qwertyShifted);
const NUMPAD_GRAPH = buildAdjacencyGraph(KEYBOARD_PATTERNS.numpad);

// Leet speak substitution map
const LEET_MAP = {
  '@': 'a', '4': 'a', '^': 'a',
  '8': 'b',
  '(': 'c', '<': 'c', '{': 'c',
  '|)': 'd',
  '3': 'e',
  'ph': 'f',
  '6': 'g', '9': 'g',
  '#': 'h',
  '1': 'i', '!': 'i', '|': 'i',
  '7': 'j',
  '|<': 'k',
  '|_': 'l',
  '0': 'o',
  '5': 's', '$': 's',
  '7': 't', '+': 't',
  '|_|': 'u',
  '\\/': 'v',
  '2': 'z'
};

// Common words used in passwords
const COMMON_WORDS = new Set([
  "love","baby","angel","girl","boy","man","woman","king","queen","lord",
  "cool","sexy","hot","sweet","cute","nice","good","best","great","super",
  "star","moon","sun","fire","ice","snow","rain","wind","storm","thunder",
  "rock","metal","gold","silver","iron","steel","stone","wood","glass","crystal",
  "wolf","bear","lion","tiger","eagle","hawk","fox","cat","dog","horse",
  "war","peace","death","life","dark","light","shadow","night","day","time",
  "power","magic","spirit","soul","heart","mind","blood","bone","flesh",
  "sword","shield","blade","arrow","axe","hammer","spear","knife","gun",
  "castle","tower","gate","wall","bridge","river","lake","ocean","mountain",
  "god","devil","demon","angel","saint","hell","heaven","paradise","eden",
  "ninja","samurai","pirate","knight","warrior","wizard","mage","rogue",
  "speed","fast","quick","slow","strong","weak","hard","soft","high","low",
  "north","south","east","west","left","right","center","middle",
  "open","close","lock","unlock","start","stop","begin","end",
  "home","house","room","door","window","floor","roof","garden","yard",
  "food","water","bread","meat","fish","milk","wine","beer","tea",
  "hand","foot","head","face","eye","ear","nose","mouth","tooth","hair"
]);

export { COMMON_PASSWORDS, KEYBOARD_PATTERNS, QWERTY_GRAPH, QWERTY_GRAPH_UPPER, NUMPAD_GRAPH, LEET_MAP, COMMON_WORDS };
