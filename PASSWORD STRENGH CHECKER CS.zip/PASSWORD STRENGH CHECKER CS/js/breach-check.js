// ============================================================
// CyberShield — Have I Been Pwned Breach Check
// Uses k-anonymity model for privacy-preserving password
// breach detection. Only first 5 chars of SHA-1 hash are sent.
// ============================================================

/**
 * Check if a password has been found in known data breaches
 * Uses the Have I Been Pwned Passwords API with k-anonymity
 * 
 * @param {string} password - Password to check
 * @returns {Object} { breached: boolean, count: number, error: string|null }
 */
export async function checkBreach(password) {
  try {
    // Step 1: Hash the password using SHA-1
    const hash = await sha1Hash(password);
    
    // Step 2: Split hash into prefix (first 5 chars) and suffix
    const prefix = hash.substring(0, 5);
    const suffix = hash.substring(5);

    // Step 3: Query the HIBP API with only the prefix (k-anonymity)
    const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
      headers: {
        'Add-Padding': 'true' // Adds padding to prevent response length analysis
      }
    });

    if (!response.ok) {
      throw new Error(`API returned status ${response.status}`);
    }

    const data = await response.text();

    // Step 4: Check if our suffix exists in the response
    const lines = data.split('\n');
    for (const line of lines) {
      const [hashSuffix, count] = line.split(':');
      if (hashSuffix.trim().toUpperCase() === suffix.toUpperCase()) {
        const breachCount = parseInt(count.trim(), 10);
        return {
          breached: true,
          count: breachCount,
          error: null
        };
      }
    }

    return {
      breached: false,
      count: 0,
      error: null
    };

  } catch (error) {
    console.error('Breach check error:', error);
    return {
      breached: false,
      count: 0,
      error: error.message || 'Unable to check breach database'
    };
  }
}

/**
 * Generate SHA-1 hash of a string using Web Crypto API
 * @param {string} message - String to hash
 * @returns {string} Uppercase hexadecimal SHA-1 hash
 */
async function sha1Hash(message) {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-1', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex.toUpperCase();
}
