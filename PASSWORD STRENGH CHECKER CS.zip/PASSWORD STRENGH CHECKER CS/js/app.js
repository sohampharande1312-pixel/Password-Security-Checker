// ============================================================
// CyberShield — Main Application Controller
// Handles UI interactions, real-time analysis, and state
// ============================================================

import { analyzePassword } from './analyzer.js';
import { generatePassword, generatePassphrase } from './generator.js';
import { checkBreach } from './breach-check.js';

// ---- DOM Elements ----
const $ = (id) => document.getElementById(id);
const passwordInput = $('passwordInput');
const passwordInputContainer = $('passwordInputContainer');
const strengthBar = $('strengthBar');
const strengthLabel = $('strengthLabel');
const strengthText = $('strengthText');
const entropyDisplay = $('entropyDisplay');
const analysisSection = $('analysisSection');
const scoreFill = $('scoreFill');
const scoreNumber = $('scoreNumber');
const toggleVisibility = $('toggleVisibility');
const clearInput = $('clearInput');
const toast = $('toast');
const header = $('header');

// Generator elements
const generatorOutput = $('generatorOutput');
const lengthSlider = $('lengthSlider');
const lengthValue = $('lengthValue');
const wordCountSlider = $('wordCountSlider');
const wordCountValue = $('wordCountValue');
const generateBtn = $('generateBtn');
const modePassword = $('modePassword');
const modePassphrase = $('modePassphrase');
const passwordControls = $('passwordControls');
const passphraseControls = $('passphraseControls');

// ---- State ----
let currentAnalysis = null;
let breachCheckTimeout = null;
let isPasswordVisible = false;
let generatorMode = 'password';
let generatorOptions = {
  lowercase: true,
  uppercase: true,
  digits: true,
  symbols: true,
  ambiguous: false,
  capitalize: true,
  includeNumber: true
};

// ============================================================
// PASSWORD ANALYSIS
// ============================================================

/**
 * Handle password input change with debounced analysis
 */
let analysisDebounce = null;
passwordInput.addEventListener('input', () => {
  clearTimeout(analysisDebounce);
  analysisDebounce = setTimeout(() => {
    runAnalysis();
  }, 150);
});

/**
 * Run full password analysis and update UI
 */
function runAnalysis() {
  const password = passwordInput.value;

  if (!password) {
    hideAnalysis();
    return;
  }

  currentAnalysis = analyzePassword(password);
  showAnalysis();
  updateStrengthBar(currentAnalysis);
  updateScoreGauge(currentAnalysis);
  updateStats(currentAnalysis);
  updateCharsetGrid(currentAnalysis);
  updateCrackTimes(currentAnalysis);
  updatePatterns(currentAnalysis);
  updateSuggestions(currentAnalysis);

  // Trigger breach check with debounce
  clearTimeout(breachCheckTimeout);
  breachCheckTimeout = setTimeout(() => {
    runBreachCheck(password);
  }, 800);
}

/**
 * Show analysis section with animation
 */
function showAnalysis() {
  analysisSection.classList.add('visible');
  strengthLabel.style.visibility = 'visible';
}

/**
 * Hide analysis section
 */
function hideAnalysis() {
  analysisSection.classList.remove('visible');
  strengthLabel.style.visibility = 'hidden';
  currentAnalysis = null;

  // Reset strength bar
  const segments = strengthBar.querySelectorAll('.strength-bar-segment');
  segments.forEach(seg => {
    seg.classList.remove('active', 'seg-1', 'seg-2', 'seg-3', 'seg-4', 'seg-5');
  });

  // Reset input container
  passwordInputContainer.className = 'password-input-container';

  // Reset score
  scoreFill.style.strokeDashoffset = '565.48';
  scoreNumber.textContent = '0';
  scoreNumber.style.color = 'var(--text-muted)';

  // Reset breach
  const breachResult = $('breachResult');
  breachResult.className = 'breach-result checking';
  breachResult.innerHTML = `
    <div class="breach-icon">🔍</div>
    <div class="breach-title">Enter a password to check</div>
    <div class="breach-detail">We'll securely check against known data breaches</div>
  `;
}

/**
 * Update the 5-segment strength bar
 */
function updateStrengthBar(analysis) {
  const { score, level } = analysis;
  const segments = strengthBar.querySelectorAll('.strength-bar-segment');

  // Determine how many segments to fill
  let activeCount = 0;
  if (score >= 10) activeCount = 1;
  if (score >= 30) activeCount = 2;
  if (score >= 50) activeCount = 3;
  if (score >= 70) activeCount = 4;
  if (score >= 85) activeCount = 5;

  segments.forEach((seg, i) => {
    seg.classList.remove('active', 'seg-1', 'seg-2', 'seg-3', 'seg-4', 'seg-5');
    if (i < activeCount) {
      seg.classList.add('active', `seg-${activeCount}`);
    }
  });

  // Update label
  strengthText.textContent = `${level.icon} ${level.label}`;
  strengthText.style.color = level.color;
  entropyDisplay.textContent = `${analysis.entropy} bits entropy`;

  // Update input container class
  passwordInputContainer.className = `password-input-container strength-${level.class}`;
}

/**
 * Animate the circular score gauge
 */
function updateScoreGauge(analysis) {
  const { score, level } = analysis;

  // Calculate stroke dash offset (full circle = 565.48, circumference of r=90)
  const circumference = 2 * Math.PI * 90;
  const offset = circumference - (score / 100) * circumference;

  scoreFill.style.strokeDashoffset = offset;
  scoreFill.style.stroke = level.color;

  // Animate number
  animateNumber(scoreNumber, score, level.color);
}

/**
 * Animate a number counting up
 */
function animateNumber(element, target, color) {
  const current = parseInt(element.textContent) || 0;
  const diff = target - current;
  const duration = 600;
  const start = performance.now();

  function update(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
    const value = Math.round(current + diff * eased);
    element.textContent = value;
    element.style.color = color;

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

/**
 * Update stat cards
 */
function updateStats(analysis) {
  $('statLength').textContent = analysis.length;
  $('statEntropy').textContent = `${analysis.entropy} bits`;
  $('statUnique').textContent = `${analysis.charsetAnalysis.uniqueChars} / ${analysis.length}`;
  $('statCharset').textContent = analysis.charsetAnalysis.charsetSize;
}

/**
 * Update character set composition grid
 */
function updateCharsetGrid(analysis) {
  const { charsetAnalysis: ca } = analysis;

  toggleCharsetItem('charLower', ca.hasLowercase);
  toggleCharsetItem('charUpper', ca.hasUppercase);
  toggleCharsetItem('charDigit', ca.hasDigits);
  toggleCharsetItem('charSymbol', ca.hasSymbols);
  toggleCharsetItem('charUnicode', ca.hasUnicode);

  $('charLowerCount').textContent = ca.lowercaseCount ? `${ca.lowercaseCount} chars` : '—';
  $('charUpperCount').textContent = ca.uppercaseCount ? `${ca.uppercaseCount} chars` : '—';
  $('charDigitCount').textContent = ca.digitCount ? `${ca.digitCount} chars` : '—';
  $('charSymbolCount').textContent = ca.symbolCount ? `${ca.symbolCount} chars` : '—';
  $('charUnicodeCount').textContent = ca.unicodeCount ? `${ca.unicodeCount} chars` : '—';
}

function toggleCharsetItem(id, active) {
  const el = $(id);
  el.classList.toggle('active', active);
  el.classList.toggle('inactive', !active);
}

/**
 * Update crack time estimation cards
 */
function updateCrackTimes(analysis) {
  const grid = $('crackTimeGrid');
  grid.innerHTML = '';

  for (const [key, scenario] of Object.entries(analysis.crackTimes)) {
    const card = document.createElement('div');
    card.className = 'crack-time-card';

    // Color code based on crack time
    let valueColor = 'var(--accent-cyan)';
    if (scenario.seconds < 1) valueColor = 'var(--accent-pink)';
    else if (scenario.seconds < 3600) valueColor = 'var(--accent-orange)';
    else if (scenario.seconds < 86400 * 30) valueColor = 'var(--accent-yellow)';
    else if (scenario.seconds < 86400 * 365) valueColor = 'var(--accent-green)';

    card.innerHTML = `
      <div class="crack-time-icon">${scenario.icon}</div>
      <div class="crack-time-value" style="color: ${valueColor}">${scenario.display}</div>
      <div class="crack-time-scenario">${scenario.name}</div>
      <div class="crack-time-description">${scenario.description}</div>
    `;

    grid.appendChild(card);
  }
}

/**
 * Update pattern detection cards
 */
function updatePatterns(analysis) {
  const list = $('patternList');
  list.innerHTML = '';

  if (analysis.patterns.length === 0) {
    list.innerHTML = `
      <div class="no-patterns">
        <div class="icon">✅</div>
        <div>No predictable patterns detected — good job!</div>
      </div>
    `;
    return;
  }

  // Deduplicate patterns by message
  const seen = new Set();
  const uniquePatterns = analysis.patterns.filter(p => {
    const key = p.type + ':' + p.message + ':' + p.detail;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  // Sort by severity
  const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  uniquePatterns.sort((a, b) => (severityOrder[a.severity] || 3) - (severityOrder[b.severity] || 3));

  uniquePatterns.forEach((pattern, i) => {
    const card = document.createElement('div');
    card.className = `pattern-card severity-${pattern.severity}`;
    card.style.animationDelay = `${i * 0.08}s`;

    card.innerHTML = `
      <span class="pattern-severity-badge ${pattern.severity}">${pattern.severity}</span>
      <div class="pattern-content">
        <div class="pattern-message">${pattern.message}</div>
        <div class="pattern-detail">${escapeHtml(pattern.detail)}</div>
      </div>
    `;

    list.appendChild(card);
  });
}

/**
 * Update improvement suggestions
 */
function updateSuggestions(analysis) {
  const list = $('suggestionList');
  list.innerHTML = '';

  analysis.suggestions.forEach((suggestion, i) => {
    const item = document.createElement('div');
    item.className = `suggestion-item priority-${suggestion.priority}`;
    item.style.animationDelay = `${i * 0.08}s`;

    item.innerHTML = `
      <span class="suggestion-icon">${suggestion.icon}</span>
      <span class="suggestion-text">${suggestion.text}</span>
    `;

    list.appendChild(item);
  });
}

/**
 * Run breach check against HIBP API
 */
async function runBreachCheck(password) {
  const breachResult = $('breachResult');

  // Show loading state
  breachResult.className = 'breach-result checking';
  breachResult.innerHTML = `
    <div class="breach-icon">🔍</div>
    <div class="breach-title">Checking breach databases...</div>
    <div class="breach-detail">Securely checking against known data breaches using k-anonymity</div>
    <div style="margin-top: 12px;"><span class="spinner"></span></div>
  `;

  const result = await checkBreach(password);

  // Make sure input hasn't changed during the check
  if (passwordInput.value !== password) return;

  if (result.error) {
    breachResult.className = 'breach-result checking';
    breachResult.innerHTML = `
      <div class="breach-icon">⚠️</div>
      <div class="breach-title">Unable to Check</div>
      <div class="breach-detail">${result.error}. Breach check requires an internet connection.</div>
    `;
  } else if (result.breached) {
    breachResult.className = 'breach-result compromised';
    breachResult.innerHTML = `
      <div class="breach-icon">🚨</div>
      <div class="breach-title" style="color: var(--accent-pink);">Password Compromised!</div>
      <div class="breach-count">${result.count.toLocaleString()} times</div>
      <div class="breach-detail">This password has been found in <strong>${result.count.toLocaleString()}</strong> data breaches. It is actively used in credential stuffing attacks. <strong>Do not use this password.</strong></div>
    `;
  } else {
    breachResult.className = 'breach-result safe';
    breachResult.innerHTML = `
      <div class="breach-icon">✅</div>
      <div class="breach-title" style="color: var(--accent-green);">Not Found in Breaches</div>
      <div class="breach-detail">This password was not found in any known data breach databases. However, this doesn't guarantee it won't be compromised in the future — strength still matters!</div>
    `;
  }
}

// ============================================================
// PASSWORD INPUT CONTROLS
// ============================================================

// Toggle visibility
toggleVisibility.addEventListener('click', () => {
  isPasswordVisible = !isPasswordVisible;
  passwordInput.type = isPasswordVisible ? 'text' : 'password';
  toggleVisibility.classList.toggle('active', isPasswordVisible);

  // Update icon
  if (isPasswordVisible) {
    toggleVisibility.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
        <line x1="1" y1="1" x2="23" y2="23"/>
      </svg>
    `;
  } else {
    toggleVisibility.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
        <circle cx="12" cy="12" r="3"/>
      </svg>
    `;
  }
});

// Clear input
clearInput.addEventListener('click', () => {
  passwordInput.value = '';
  passwordInput.focus();
  hideAnalysis();
});

// ============================================================
// PASSWORD GENERATOR
// ============================================================

// Mode tabs
modePassword.addEventListener('click', () => switchMode('password'));
modePassphrase.addEventListener('click', () => switchMode('passphrase'));

function switchMode(mode) {
  generatorMode = mode;
  modePassword.classList.toggle('active', mode === 'password');
  modePassphrase.classList.toggle('active', mode === 'passphrase');
  passwordControls.style.display = mode === 'password' ? 'flex' : 'none';
  passphraseControls.style.display = mode === 'passphrase' ? 'flex' : 'none';
  generateBtn.textContent = mode === 'password' ? '⚡ Generate Secure Password' : '⚡ Generate Secure Passphrase';
}

// Length slider
lengthSlider.addEventListener('input', () => {
  lengthValue.textContent = lengthSlider.value;
});

// Word count slider
wordCountSlider.addEventListener('input', () => {
  wordCountValue.textContent = wordCountSlider.value;
});

// Toggle switches
document.querySelectorAll('.toggle-item').forEach(item => {
  item.addEventListener('click', () => {
    const toggle = item.querySelector('.toggle-switch');
    const key = toggle.dataset.toggle;
    toggle.classList.toggle('active');
    generatorOptions[key] = toggle.classList.contains('active');
  });
});

// Generate button
generateBtn.addEventListener('click', () => {
  let generated;

  if (generatorMode === 'password') {
    generated = generatePassword({
      length: parseInt(lengthSlider.value),
      includeLowercase: generatorOptions.lowercase,
      includeUppercase: generatorOptions.uppercase,
      includeDigits: generatorOptions.digits,
      includeSymbols: generatorOptions.symbols,
      excludeAmbiguous: generatorOptions.ambiguous
    });
  } else {
    generated = generatePassphrase({
      wordCount: parseInt(wordCountSlider.value),
      separator: '-',
      capitalize: generatorOptions.capitalize,
      includeNumber: generatorOptions.includeNumber
    });
  }

  generatorOutput.textContent = generated;

  // Add a brief flash animation
  generatorOutput.style.transition = 'none';
  generatorOutput.style.color = 'var(--accent-cyan)';
  setTimeout(() => {
    generatorOutput.style.transition = 'color 0.5s ease';
    generatorOutput.style.color = 'var(--text-primary)';
  }, 50);
});

// Copy generated password
$('copyGenerated').addEventListener('click', () => {
  const text = generatorOutput.textContent;
  if (text && text !== 'Click "Generate" to create a secure password') {
    copyToClipboard(text);
  }
});

// Analyze generated password
$('analyzeGenerated').addEventListener('click', () => {
  const text = generatorOutput.textContent;
  if (text && text !== 'Click "Generate" to create a secure password') {
    passwordInput.value = text;
    passwordInput.type = 'text';
    isPasswordVisible = true;
    toggleVisibility.classList.add('active');
    toggleVisibility.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
        <line x1="1" y1="1" x2="23" y2="23"/>
      </svg>
    `;
    runAnalysis();

    // Scroll to analyzer
    document.querySelector('#analyzer').scrollIntoView({ behavior: 'smooth' });
  }
});

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

/**
 * Copy text to clipboard and show toast
 */
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('✅ Copied to clipboard!');
  } catch {
    // Fallback
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.opacity = '0';
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
    showToast('✅ Copied to clipboard!');
  }
}

/**
 * Show toast notification
 */
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2500);
}

/**
 * Escape HTML entities
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ============================================================
// HEADER SCROLL EFFECT
// ============================================================

let lastScrollY = 0;
window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;
  header.classList.toggle('scrolled', scrollY > 20);
  lastScrollY = scrollY;
}, { passive: true });

// ============================================================
// MOBILE MENU
// ============================================================

$('mobileMenuBtn').addEventListener('click', () => {
  $('navLinks').classList.toggle('open');
});

// Close mobile menu when clicking a link
document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    $('navLinks').classList.remove('open');
  });
});

// ============================================================
// SMOOTH SCROLL FOR ANCHOR LINKS
// ============================================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    e.preventDefault();
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ============================================================
// INITIALIZE
// ============================================================

// Focus password input on load
window.addEventListener('load', () => {
  setTimeout(() => passwordInput.focus(), 500);
});

// Generate initial password
generateBtn.click();
