// ============================================================
// CyberShield — Pattern Detection Engine
// Detects predictable patterns that weaken passwords
// ============================================================

import { COMMON_PASSWORDS, QWERTY_GRAPH, QWERTY_GRAPH_UPPER, NUMPAD_GRAPH, LEET_MAP, COMMON_WORDS } from './data/common-passwords.js';

/**
 * Master pattern detection function
 * Returns an array of detected pattern objects
 */
export function detectPatterns(password) {
  const patterns = [];

  patterns.push(...detectDictionaryMatch(password));
  patterns.push(...detectKeyboardPatterns(password));
  patterns.push(...detectSequences(password));
  patterns.push(...detectRepeats(password));
  patterns.push(...detectLeetSpeak(password));
  patterns.push(...detectDates(password));
  patterns.push(...detectCommonAffixes(password));

  return patterns;
}

/**
 * Check if password (or variations) exists in common password lists
 */
export function detectDictionaryMatch(password) {
  const patterns = [];
  const lower = password.toLowerCase();

  // Direct match
  if (COMMON_PASSWORDS.has(lower)) {
    patterns.push({
      type: 'dictionary',
      severity: 'critical',
      message: 'This is a commonly used password found in breach databases',
      detail: `"${password}" appears in the top most common passwords list`,
      penalty: 0.95,
      indices: [0, password.length - 1]
    });
  }

  // Check substrings (min length 4)
  for (let i = 0; i < lower.length; i++) {
    for (let len = 4; len <= lower.length - i; len++) {
      const sub = lower.substring(i, i + len);
      if (COMMON_PASSWORDS.has(sub) && sub !== lower) {
        patterns.push({
          type: 'dictionary',
          severity: 'high',
          message: 'Contains a common password as a substring',
          detail: `Found "${sub}" which is a commonly used password`,
          penalty: 0.3 * (len / password.length),
          indices: [i, i + len - 1]
        });
        break; // Only flag the longest match starting at this position
      }
    }
  }

  // Common word check
  for (const word of COMMON_WORDS) {
    const idx = lower.indexOf(word);
    if (idx !== -1 && word.length >= 4) {
      patterns.push({
        type: 'dictionary',
        severity: 'medium',
        message: 'Contains a common dictionary word',
        detail: `Found "${word}" — dictionary words are easily guessable`,
        penalty: 0.15,
        indices: [idx, idx + word.length - 1]
      });
    }
  }

  return patterns;
}

/**
 * Detect keyboard walk patterns (qwerty, asdfgh, etc.)
 */
export function detectKeyboardPatterns(password) {
  const patterns = [];

  function findWalks(str, graph, label) {
    let walkStart = 0;
    let walkLength = 1;

    for (let i = 1; i < str.length; i++) {
      const prevChar = str[i - 1].toLowerCase();
      const currChar = str[i].toLowerCase();
      const neighbors = graph[prevChar] || [];

      if (neighbors.includes(currChar)) {
        walkLength++;
      } else {
        if (walkLength >= 3) {
          patterns.push({
            type: 'keyboard',
            severity: walkLength >= 5 ? 'high' : 'medium',
            message: `Keyboard pattern detected (${label})`,
            detail: `"${str.substring(walkStart, walkStart + walkLength)}" is a keyboard walk pattern`,
            penalty: Math.min(0.5, 0.1 * walkLength),
            indices: [walkStart, walkStart + walkLength - 1]
          });
        }
        walkStart = i;
        walkLength = 1;
      }
    }

    // Check final walk
    if (walkLength >= 3) {
      patterns.push({
        type: 'keyboard',
        severity: walkLength >= 5 ? 'high' : 'medium',
        message: `Keyboard pattern detected (${label})`,
        detail: `"${str.substring(walkStart, walkStart + walkLength)}" is a keyboard walk pattern`,
        penalty: Math.min(0.5, 0.1 * walkLength),
        indices: [walkStart, walkStart + walkLength - 1]
      });
    }
  }

  findWalks(password, QWERTY_GRAPH, 'QWERTY');
  findWalks(password, NUMPAD_GRAPH, 'Numpad');

  return patterns;
}

/**
 * Detect sequential characters (abc, 123, zyx, etc.)
 */
export function detectSequences(password) {
  const patterns = [];

  function checkSequence(str) {
    let seqStart = 0;
    let seqLength = 1;
    let direction = 0; // 1 = ascending, -1 = descending

    for (let i = 1; i < str.length; i++) {
      const diff = str.charCodeAt(i) - str.charCodeAt(i - 1);

      if (diff === 1 || diff === -1) {
        if (direction === 0 || direction === diff) {
          direction = diff;
          seqLength++;
        } else {
          if (seqLength >= 3) {
            const seq = str.substring(seqStart, seqStart + seqLength);
            const dir = direction === 1 ? 'ascending' : 'descending';
            patterns.push({
              type: 'sequence',
              severity: seqLength >= 5 ? 'high' : 'medium',
              message: `Sequential ${dir} characters detected`,
              detail: `"${seq}" is a predictable ${dir} sequence`,
              penalty: Math.min(0.5, 0.1 * seqLength),
              indices: [seqStart, seqStart + seqLength - 1]
            });
          }
          seqStart = i - 1;
          seqLength = 2;
          direction = diff;
        }
      } else {
        if (seqLength >= 3) {
          const seq = str.substring(seqStart, seqStart + seqLength);
          const dir = direction === 1 ? 'ascending' : 'descending';
          patterns.push({
            type: 'sequence',
            severity: seqLength >= 5 ? 'high' : 'medium',
            message: `Sequential ${dir} characters detected`,
            detail: `"${seq}" is a predictable ${dir} sequence`,
            penalty: Math.min(0.5, 0.1 * seqLength),
            indices: [seqStart, seqStart + seqLength - 1]
          });
        }
        seqStart = i;
        seqLength = 1;
        direction = 0;
      }
    }

    // Check final sequence
    if (seqLength >= 3) {
      const seq = str.substring(seqStart, seqStart + seqLength);
      const dir = direction === 1 ? 'ascending' : 'descending';
      patterns.push({
        type: 'sequence',
        severity: seqLength >= 5 ? 'high' : 'medium',
        message: `Sequential ${dir} characters detected`,
        detail: `"${seq}" is a predictable ${dir} sequence`,
        penalty: Math.min(0.5, 0.1 * seqLength),
        indices: [seqStart, seqStart + seqLength - 1]
      });
    }
  }

  checkSequence(password);

  return patterns;
}

/**
 * Detect repeated characters or groups
 */
export function detectRepeats(password) {
  const patterns = [];

  // Single character repeats (3+)
  const singleRepeat = /(.)\1{2,}/g;
  let match;
  while ((match = singleRepeat.exec(password)) !== null) {
    patterns.push({
      type: 'repeat',
      severity: match[0].length >= 5 ? 'high' : 'medium',
      message: 'Repeated character detected',
      detail: `"${match[0]}" — repeating "${match[1]}" ${match[0].length} times adds no security`,
      penalty: Math.min(0.4, 0.08 * match[0].length),
      indices: [match.index, match.index + match[0].length - 1]
    });
  }

  // Group repeats (e.g., "abcabc")
  for (let groupLen = 2; groupLen <= Math.floor(password.length / 2); groupLen++) {
    for (let start = 0; start <= password.length - groupLen * 2; start++) {
      const group = password.substring(start, start + groupLen);
      let repeatCount = 1;
      let pos = start + groupLen;

      while (pos + groupLen <= password.length && password.substring(pos, pos + groupLen) === group) {
        repeatCount++;
        pos += groupLen;
      }

      if (repeatCount >= 2) {
        const fullMatch = group.repeat(repeatCount);
        patterns.push({
          type: 'repeat',
          severity: 'medium',
          message: 'Repeated pattern group detected',
          detail: `"${fullMatch}" — the group "${group}" repeats ${repeatCount} times`,
          penalty: 0.2,
          indices: [start, start + fullMatch.length - 1]
        });
      }
    }
  }

  return patterns;
}

/**
 * Detect leet speak substitutions
 */
export function detectLeetSpeak(password) {
  const patterns = [];

  // Try to decode leet speak
  let decoded = password.toLowerCase();
  const singleCharLeet = {
    '@': 'a', '4': 'a', '^': 'a',
    '8': 'b',
    '3': 'e',
    '6': 'g',
    '#': 'h',
    '1': 'i', '!': 'i',
    '0': 'o',
    '5': 's', '$': 's',
    '+': 't',
    '2': 'z'
  };

  let hasLeetChars = false;
  let decodedStr = '';
  for (const char of decoded) {
    if (singleCharLeet[char]) {
      decodedStr += singleCharLeet[char];
      hasLeetChars = true;
    } else {
      decodedStr += char;
    }
  }

  if (hasLeetChars) {
    // Check decoded version against common passwords
    if (COMMON_PASSWORDS.has(decodedStr)) {
      patterns.push({
        type: 'leet',
        severity: 'critical',
        message: 'Leet speak substitution of a common password',
        detail: `"${password}" decodes to "${decodedStr}" which is a common password. Leet speak substitutions are well-known to attackers.`,
        penalty: 0.85,
        indices: [0, password.length - 1]
      });
    }

    // Check against common words
    for (const word of COMMON_WORDS) {
      if (decodedStr.includes(word) && word.length >= 4) {
        patterns.push({
          type: 'leet',
          severity: 'medium',
          message: 'Leet speak substitution detected',
          detail: `Contains leet speak version of "${word}" — attackers know these substitutions`,
          penalty: 0.12,
          indices: [0, password.length - 1]
        });
        break;
      }
    }
  }

  return patterns;
}

/**
 * Detect date patterns in various formats
 */
export function detectDates(password) {
  const patterns = [];

  const dateRegexes = [
    { regex: /(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})/g, format: 'MM/DD/YYYY' },
    { regex: /(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})/g, format: 'YYYY/MM/DD' },
    { regex: /(\d{2})(\d{2})(\d{4})/g, format: 'MMDDYYYY' },
    { regex: /(\d{4})(\d{2})(\d{2})/g, format: 'YYYYMMDD' },
    { regex: /(19|20)\d{2}/g, format: 'year' }
  ];

  for (const { regex, format } of dateRegexes) {
    let match;
    while ((match = regex.exec(password)) !== null) {
      if (format === 'year') {
        patterns.push({
          type: 'date',
          severity: 'low',
          message: 'Year detected in password',
          detail: `"${match[0]}" looks like a year — dates are easily guessable`,
          penalty: 0.08,
          indices: [match.index, match.index + match[0].length - 1]
        });
      } else {
        patterns.push({
          type: 'date',
          severity: 'medium',
          message: 'Date pattern detected',
          detail: `"${match[0]}" appears to be a date (${format}) — personal dates are easily guessable`,
          penalty: 0.2,
          indices: [match.index, match.index + match[0].length - 1]
        });
      }
    }
  }

  return patterns;
}

/**
 * Detect common weak prefixes/suffixes
 */
export function detectCommonAffixes(password) {
  const patterns = [];

  const commonSuffixes = ['123','1234','12345','!','!!','!!!','1','01','1!','@','#','$','69','007','666','777','888','999'];
  const commonPrefixes = ['the','my','i','a','1','123'];

  const lower = password.toLowerCase();

  for (const suffix of commonSuffixes) {
    if (lower.endsWith(suffix) && lower.length > suffix.length) {
      patterns.push({
        type: 'affix',
        severity: 'low',
        message: 'Common suffix detected',
        detail: `Appending "${suffix}" is a very common pattern that attackers check first`,
        penalty: 0.1,
        indices: [password.length - suffix.length, password.length - 1]
      });
      break;
    }
  }

  for (const prefix of commonPrefixes) {
    if (lower.startsWith(prefix) && lower.length > prefix.length) {
      patterns.push({
        type: 'affix',
        severity: 'low',
        message: 'Common prefix detected',
        detail: `Starting with "${prefix}" is a predictable pattern`,
        penalty: 0.05,
        indices: [0, prefix.length - 1]
      });
      break;
    }
  }

  return patterns;
}
