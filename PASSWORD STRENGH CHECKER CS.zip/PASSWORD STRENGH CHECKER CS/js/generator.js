// ============================================================
// CyberShield — Secure Password Generator
// Uses crypto.getRandomValues() for cryptographic randomness
// ============================================================

const CHAR_SETS = {
  lowercase: 'abcdefghijklmnopqrstuvwxyz',
  uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  digits: '0123456789',
  symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?/~`',
  ambiguous: 'il1Lo0O'
};

// Word list for passphrase generation (common English words, 4-8 letters)
const WORD_LIST = [
  "about","above","adapt","admit","adopt","after","again","agree","alarm","alert",
  "alive","allow","alone","along","alter","ample","anger","angle","ankle","apple",
  "arena","argue","arise","aside","asset","avoid","award","bacon","badge","baker",
  "basic","beach","begin","below","bench","berry","birth","black","blade","blame",
  "blank","blast","blaze","bleed","blend","bless","blind","block","blood","bloom",
  "blown","board","bonus","boost","bound","brain","brand","brave","bread","break",
  "breed","brick","brief","bring","broad","broke","brook","brush","build","bunch",
  "burst","buyer","cabin","cable","camel","candy","cargo","carry","catch","cause",
  "cedar","chain","chair","chalk","champ","chaos","charm","chase","cheap","check",
  "chess","chief","child","chord","chunk","civic","claim","clash","class","clean",
  "clear","climb","cling","clock","close","cloth","cloud","coach","coast","coral",
  "count","court","cover","crack","craft","crane","crash","crazy","cream","creek",
  "crisp","cross","crowd","crown","crush","curve","cycle","daily","dance","depth",
  "diary","digit","diner","disco","ditch","dodge","donor","doubt","draft","drain",
  "drama","drank","dream","dress","drift","drink","drive","drone","drove","dying",
  "eager","eagle","early","earth","eight","elbow","elder","elite","embed","empty",
  "enjoy","enter","equal","equip","error","essay","event","every","exact","exile",
  "exist","extra","fable","facet","faith","fancy","fatal","fault","feast","fever",
  "fiber","field","fifth","fifty","fight","final","flame","flash","fleet","flesh",
  "fling","float","flood","floor","flora","fluid","flush","focal","focus","force",
  "forge","forth","forum","found","frame","frank","fraud","fresh","front","frost",
  "fruit","gains","ghost","giant","gives","gland","glass","gleam","globe","glory",
  "gloss","going","grace","grade","grain","grand","grant","graph","grasp","grass",
  "grave","great","green","grind","groan","group","grove","grown","guard","guess",
  "guide","habit","happy","harsh","haven","heart","heavy","hedge","hello","hence",
  "honey","honor","horse","hotel","house","human","humor","hurry","hyper","ideal",
  "image","imply","inbox","index","indie","indie","inner","input","ivory","jewel",
  "joint","joker","juice","jumbo","jumps","judge","knack","kneel","knife","knock",
  "known","label","labor","lance","large","laser","later","laugh","layer","leads",
  "learn","legal","lemon","level","light","limit","linen","liner","links","liver",
  "local","logic","looks","lover","lower","lucky","lunar","lunch","lyric","magic",
  "major","maker","manor","maple","march","match","mayor","media","melon","mercy",
  "merit","metal","meter","might","miner","minor","minus","mixed","model","money",
  "month","moral","motor","mount","mouse","moved","movie","music","naive","nerve",
  "never","night","noble","noise","north","notch","noted","novel","nurse","nylon",
  "ocean","offer","olive","onset","opera","orbit","order","organ","other","outer",
  "oxide","ozone","panda","panel","panic","paper","patch","pause","peace","pearl",
  "pedal","penny","perch","phase","phone","photo","piano","piece","pilot","pinch",
  "pitch","pixel","pizza","place","plain","plane","plant","plate","plaza","plead",
  "plumb","plume","plunk","point","polar","pop","pound","power","press","price",
  "pride","prime","print","prior","prize","probe","proof","proud","proxy","pulse",
  "punch","pupil","purse","queen","query","quest","quick","quiet","quota","quote",
  "radar","radio","raise","rally","ranch","range","rapid","ratio","reach","ready",
  "realm","rebel","reign","relax","relay","renal","renew","reply","ridge","rifle",
  "right","rigid","risky","rival","river","robot","rocky","rouge","rough","round",
  "route","royal","rumor","rural","safer","saint","salad","sauce","scale","scene",
  "scope","score","sense","serve","seven","shade","shake","shall","shame","shape",
  "share","shark","sharp","sheep","sheer","shelf","shell","shift","shine","shirt",
  "shock","shore","short","shout","sight","sigma","since","sixth","sixty","skill",
  "skull","slash","slate","sleep","slice","slide","slope","smart","smell","smile",
  "smoke","snack","snake","solar","solid","solve","sonic","sorry","sound","south",
  "space","spare","spark","speak","spear","speed","spend","spice","spill","spine",
  "spoke","spoon","spray","squad","stack","staff","stage","stain","stake","stall",
  "stamp","stand","start","state","stays","steam","steel","steep","steer","stern",
  "stick","stiff","still","stock","stone","stood","store","storm","story","stout",
  "stove","strap","straw","strip","stuck","stuff","style","sugar","suite","super",
  "surge","swamp","swear","sweep","sweet","swept","swift","swing","sword","syrup",
  "table","taste","teeth","tempo","thank","theme","thick","thing","think","third",
  "thorn","those","three","threw","throw","thumb","tiger","tight","timer","tired",
  "title","toast","token","topic","torch","total","touch","tough","towel","tower",
  "toxic","trace","track","trade","trail","train","trait","trash","treat","trend",
  "trial","tribe","trick","tried","troop","truck","truly","trump","trunk","trust",
  "truth","tumor","tweed","twice","twist","ultra","uncle","under","unify","union",
  "unite","unity","until","upper","upset","urban","usage","usual","utter","valid",
  "valor","value","valve","vault","venue","verse","vigor","viral","virus","visit",
  "vista","vital","vivid","vocal","voice","voter","wagon","waist","waste","watch",
  "water","weave","weigh","weird","wheat","wheel","where","which","while","white",
  "whole","widen","width","witch","woman","world","worry","worse","worst","worth",
  "would","wound","wrath","write","wrong","yacht","yield","young","youth","zebra",
  "pixel","prism","plumb","prowl","quest","roast","rover","scald","scout","shrug",
  "siege","skate","sling","snare","solar","spade","sprig","squid","stage","stomp",
  "stork","swirl","talon","tango","thief","torch","tulip","twirl","venom","vigor",
  "whirl","wreck","amber","badge","cadet","decoy","ember","flare","glyph","hurry",
  "ivory","joust","karma","latch","mocha","nexus","optic","plume","quilt","relic",
  "sauna","tidal","umbra","vault","wager","xenon","yield","zesty"
];

/**
 * Generate a random password with given options
 * @param {Object} options 
 * @returns {string} Generated password
 */
export function generatePassword(options = {}) {
  const {
    length = 16,
    includeLowercase = true,
    includeUppercase = true,
    includeDigits = true,
    includeSymbols = true,
    excludeAmbiguous = false
  } = options;

  let charset = '';
  const requiredChars = [];

  if (includeLowercase) {
    let chars = CHAR_SETS.lowercase;
    if (excludeAmbiguous) chars = chars.replace(/[l]/g, '');
    charset += chars;
    requiredChars.push(chars);
  }
  if (includeUppercase) {
    let chars = CHAR_SETS.uppercase;
    if (excludeAmbiguous) chars = chars.replace(/[IO]/g, '');
    charset += chars;
    requiredChars.push(chars);
  }
  if (includeDigits) {
    let chars = CHAR_SETS.digits;
    if (excludeAmbiguous) chars = chars.replace(/[01]/g, '');
    charset += chars;
    requiredChars.push(chars);
  }
  if (includeSymbols) {
    charset += CHAR_SETS.symbols;
    requiredChars.push(CHAR_SETS.symbols);
  }

  if (charset.length === 0) {
    charset = CHAR_SETS.lowercase;
    requiredChars.push(CHAR_SETS.lowercase);
  }

  // Generate password ensuring at least one char from each required set
  let password = [];

  // First, add one random char from each required set
  for (const req of requiredChars) {
    password.push(req[secureRandom(req.length)]);
  }

  // Fill remaining length with random chars from full charset
  while (password.length < length) {
    password.push(charset[secureRandom(charset.length)]);
  }

  // Shuffle the password using Fisher-Yates
  for (let i = password.length - 1; i > 0; i--) {
    const j = secureRandom(i + 1);
    [password[i], password[j]] = [password[j], password[i]];
  }

  return password.join('');
}

/**
 * Generate a passphrase using random words
 * @param {Object} options
 * @returns {string} Generated passphrase
 */
export function generatePassphrase(options = {}) {
  const {
    wordCount = 5,
    separator = '-',
    capitalize = true,
    includeNumber = true
  } = options;

  const words = [];
  
  for (let i = 0; i < wordCount; i++) {
    let word = WORD_LIST[secureRandom(WORD_LIST.length)];
    if (capitalize) {
      word = word.charAt(0).toUpperCase() + word.slice(1);
    }
    words.push(word);
  }

  // Insert a random number at a random position
  if (includeNumber) {
    const num = secureRandom(100);
    const pos = secureRandom(words.length + 1);
    words.splice(pos, 0, num.toString());
  }

  return words.join(separator);
}

/**
 * Generate cryptographically secure random number
 * @param {number} max - Exclusive upper bound
 * @returns {number} Random integer in [0, max)
 */
function secureRandom(max) {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  return array[0] % max;
}
